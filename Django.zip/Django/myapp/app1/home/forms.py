from django import forms
from django.core.validators import RegexValidator
class SimpleForm(forms.Form):
    '''Now describe your  form here '''
    first_name = forms.CharField(
        validators=[
             RegexValidator(
                 regex=r'^[A-Za-z]{3,12}$',
                 message="Firstname cant allow numbers only letters min 3 to 12 chars long",
                 code="first_name_error"
             )
        ],
        widget=forms.TextInput(attrs={
            'class':'form-control',
            'placeholder':'e.g John'
        })
    )
    last_name = forms.CharField(
        widget=forms.TextInput(attrs={
            'class':'form-control',
            'placeholder':'e.g Doe'
        })
    )
    city_options=[
        ('','---Choose a City---'),
        ('Kolkata','Kolkata'),
        ('Chennai','Chennai'),
        ('Mumbai','Mumbai')
    ]  
    gender_options = [
        ('Male','Male'),
        ('Female','Female'),
        ('Others','TransGender')
    ]
    gender = forms.ChoiceField(
        choices=gender_options,
        widget=forms.RadioSelect
    )
    city = forms.ChoiceField(
        choices=city_options,
        widget=forms.Select
    )
    address = forms.CharField(
        widget=forms.Textarea(attrs={
            'class':'form-control',
            'placeholder':'Address',
            'rows':10,
            'cols':30
        })
    )
