from django.urls import path
from . import views
#child routes has been configured
urlpatterns = [
    path("",views.home,name='home') 
]
#upto date