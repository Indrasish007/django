from django.urls import path
from . import views
#child Routes has been configured.
urlpatterns= [
    path("",views.home,name='home'),
    # path("show",views.send,name='show'),
    path("numbers",views.sendNumber,name='numbers'),
    path("users/",views.sendUsersInfo,name='users'),
    path("calc/",views.sendNumber,name='calc'),
    path("signup/",views.form_view),
    path("submit/",views.submit,name='submit_handler')
]