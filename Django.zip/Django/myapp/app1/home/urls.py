from django.urls import path
from . import views
#child routes has been configured
urlpatterns = [
    path("",views.home,name='home'),
    path("numbers",views.sendNumber,name='numbers'),
    path("users",views.sendUsersInfo,name='users')
]
#upto date