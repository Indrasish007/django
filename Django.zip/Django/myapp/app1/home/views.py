from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
# Create your views here.

def home(request):
    template=loader.get_template("home/myhome.html")
    return HttpResponse(template.render())
#we are defining another function which will returns some values to template
# def send(request):
#     template=loader.get_template("home/show.html")
#     message={
#         "firstName":"John",
#         "lastName":"Doe",
#         "salaryInfo":{
#             "basic":12000,
#             "HRA":0.02,
#             "TDS":0.01,
#             "DA":0.02
#         },
#         "contactInfo":{
#             "phone":"7001258963",
#             "e-mail":"john@gmail.com"
#         },
#         "address":{
#             "state":"WB",
#             "city":"Kolkata",
#             "pincode":712235
#         }
#     }
#     DA= message["salaryInfo"]['basic']*message["salaryInfo"]['DA']
#     message['salaryInfo']['DA']=DA
#     HRA= message["salaryInfo"]['basic']*message["salaryInfo"]['HRA']
#     message['salaryInfo']['HRA']=HRA
#     TDS= message["salaryInfo"]['basic']*message["salaryInfo"]['TDS']
#     message['salaryInfo']['TDS']=TDS
#     GROSS= message["salaryInfo"]['basic']+HRA+DA-TDS
#     message['salaryInfo']['basic']=GROSS
#     #this is where we are binding value and sending through request
#     return HttpResponse(template.render(message,request))