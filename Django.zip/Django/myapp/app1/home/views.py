from django.template import loader
from django.http import HttpResponse
from django.shortcuts import render

def home(request):
    return render(request, "home/myhome.html")

def sendUsersInfo(request):
    users = [
        {
            "id": 1,
            "name": "John",
            "age": 33,
            "address": {
                "state": "WB",
                "city": "Kolkata",
                "pincode": "712235"
            },
            "phones": ["1234", "45667"]
        },
        {
            "id": 2,
            "name": "Jenny",
            "age": 25,
            "address": {
                "state": "WB",
                "city": "Saltlake",
                "pincode": "67676767"
            },
            "phones": ["34556", "55677"]
        },
        {
            "id": 3,
            "name": "Jerry",
            "age": 23,
            "address": {
                "state": "WB",
                "city": "Konnagar",
                "pincode": "76767676"
            },
            "phones": ["566788", "66788"]
        }
    ]

    return render(request, "home/users.html", {"users": users})

def sendNumber(request):
    template=loader.get_template("home/calc.html")
    params={
        "x":100,
        "m":2,
        "n":3
    }
    return HttpResponse(template.render(params,request))


from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
# Create your views here.
from .forms import SimpleForm

from django.views.decorators.csrf import csrf_exempt


@csrf_exempt
def form_view(request):
    template = loader.get_template("home/signup.html")
    context={} #Empty dictionary
    context['myform'] = SimpleForm()
    return HttpResponse(template.render(context,request))
@csrf_exempt
def submit(request):
    if request.method == 'POST':
        myform = SimpleForm(request.POST)
        if(myform.is_valid()):

          message = {
            'name': myform.cleaned_data['first_name'] +" "+myform.cleaned_data['last_name'],
            'gender':myform.cleaned_data['gender'],
             'addr':{
                 'city':myform.cleaned_data['city'],
                 'address':myform.cleaned_data['address']
             }
          }
          template = loader.get_template("home/signup.html")
          return HttpResponse(template.render({'message':message},request))
        else :
            #we need to return server side errors to home/signup.html Page.
            template = loader.get_template("home/signup.html")
            return HttpResponse(template.render({"myform":myform},request))
