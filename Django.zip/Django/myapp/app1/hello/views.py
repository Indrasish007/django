from django.shortcuts import render

#As we want to send a particular response we have to import the following files 

from django.http import HttpResponse

# Create your views here.
def hello(request):
    return HttpResponse("<h1>Welcome to django</h1>")
def hii(request):
    return HttpResponse("<h4>Hiiiii</h4>")
