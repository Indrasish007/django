from collections import UserString
from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
# Create your views here.

def home(request):
    template=loader.get_template("home/myhome.html")
    return HttpResponse(template.render())

def sendUsersInfo(request):
    template=loader.get_template("home/users.html")
    users=[
        {"id":1,"name":"John","age":33,"address":{"state":"WB","city":"Kolkata","pincode":"712235"},"phones":['1234','45667']},
        {"id":2,"name":"Jenny","age":25,"address":{"state":"WB","city":"Saltlake","pincode":"67676767"},"phones":['34556','55677']},
        {"id":3,"name":"Jerry","age":23,"address":{"state":"WB","city":"Konnagar","pincode":"76767676"},"phones":['566788','66788']},
        {"id":4,"name":"Diana","age":26,"address":{"state":"MAHARASTRA","city":"Mumbai","pincode":"7888878"},"phones":['1234','444456']}
    ]
    context={
        "users":users
    }
    return HttpResponse(template.render(context,request))
def sendNumber(request):
    template=loader.get_template("home/calc.html")
    params={
        "x":100,
        "m":2,
        "n":3
    }
    return HttpResponse(template.render(params,request))

def home(request):
    return render(request, "home/myhome.html")


# we are defining another function which will returns some values to template
# def send(request):
#     template=loader.get_template("home/show.html")
#     message={
#         "firstName":"John",
#         "lastName":"Doe",
#         "salaryInfo":{
#             "basic":12000,
#             "HRA":0.02,
#             "TDS":0.01,
#             "DA":0.02
#         },
#         "contactInfo":{
#             "phone":"7001258963",
#             "e-mail":"john@gmail.com"
#         },
#         "address":{
#             "state":"WB",
#             "city":"Kolkata",
#             "pincode":712235
#         }
#     }
#     DA= message["salaryInfo"]['basic']*message["salaryInfo"]['DA']
#     message['salaryInfo']['DA']=DA
#     HRA= message["salaryInfo"]['basic']*message["salaryInfo"]['HRA']
#     message['salaryInfo']['HRA']=HRA
#     TDS= message["salaryInfo"]['basic']*message["salaryInfo"]['TDS']
#     message['salaryInfo']['TDS']=TDS
#     GROSS= message["salaryInfo"]['basic']+HRA+DA-TDS
#     message['salaryInfo']['basic']=GROSS
#     #this is where we are binding value and sending through request
#     return HttpResponse(template.render(message,request))






