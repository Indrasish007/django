from django.shortcuts import render

def home(request):
    return render(request, "home/myhome.html")

def sendUsersInfo(request):
    users = [
        {
            "id": 1,
            "name": "John",
            "age": 33,
            "address": {
                "state": "WB",
                "city": "Kolkata",
                "pincode": "712235"
            },
            "phones": ["1234", "45667"]
        },
        {
            "id": 2,
            "name": "Jenny",
            "age": 25,
            "address": {
                "state": "WB",
                "city": "Saltlake",
                "pincode": "67676767"
            },
            "phones": ["34556", "55677"]
        },
        {
            "id": 3,
            "name": "Jerry",
            "age": 23,
            "address": {
                "state": "WB",
                "city": "Konnagar",
                "pincode": "76767676"
            },
            "phones": ["566788", "66788"]
        }
    ]

    return render(request, "home/users.html", {"users": users})

def sendNumber(request):
    numbers = [1, 2, 3, 4, 5]
    return render(request, "home/calc.html", {"numbers": numbers})
